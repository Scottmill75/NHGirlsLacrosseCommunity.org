const menuButton = document.querySelector('.menu-toggle');
const navLinks = document.querySelector('.nav-links');

menuButton.addEventListener('click', () => {
  const open = navLinks.classList.toggle('open');
  menuButton.setAttribute('aria-expanded', open);
});

document.querySelectorAll('.nav-links a').forEach(link => {
  link.addEventListener('click', () => {
    navLinks.classList.remove('open');
    menuButton.setAttribute('aria-expanded', 'false');
  });
});

const joinForm = document.getElementById('joinForm');
const formStatus = document.getElementById('formStatus');

joinForm.addEventListener('submit', event => {
  event.preventDefault();
  const name = new FormData(joinForm).get('name');
  formStatus.textContent = `Thanks, ${name}! This prototype form is ready to connect to your email list or database.`;
  joinForm.reset();
});

const eventDialog = document.getElementById('eventDialog');
document.getElementById('openEventForm').addEventListener('click', () => {
  eventDialog.showModal();
});
